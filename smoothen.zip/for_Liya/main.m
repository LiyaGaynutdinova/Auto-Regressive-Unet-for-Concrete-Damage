clear all
addpath('./fun');

inputFolder = './data';
inputName = '4.particles';

options = struct( ...
    'relativeAdditionalDistance',   0.4, ...    % Key control: additional radius compred to the circumscribed radius (set from 0 to cca 0.4 or 0.5, more is unstable)
    'similarityThreshold',          1e-2, ...
    'maxIterations',                20, ...
    'plotIntermediate',             false, ...   % Set False to make it faster, set true to see what is going on
    'resolution',                   [ 101, 101] );

[newData, newImg] = smoothen_particles(fullfile(inputFolder,inputName), options);

figure();
imshow(newImg);
