function [ LS ] = compute_LS_polygon_v2( coords, X, Y )
% COMPUTE_LS_POLYGON computes level set for polygon inclusion on a grid
% defined with X and Y matrices following the article Sonon et. al., CMAME, 2012
%
%   * requires definition of th inclusion vertices in the clockwise order

[ nVert, dim ] = size( coords );

if dim ~= 3
    if dim == 2
        coords = [ coords, zeros(nVert,1) ];
    else
        error('Dimension of the vertex coordinates must be neither 2 nor 3.\n');
    end
end

% precompute auxiliary data
A = (1:nVert)';
B = [ (2:nVert)'; 1];           % Next vertex
C = [ nVert; (1:nVert-1)' ];    % Previous vertex

AB = coords(B,:) - coords(A,:);
AB_norm = sqrt(sum(AB.^2, 2));
E = AB ./ AB_norm;

S_aux = cross( coords(B,:) - coords(A,:), coords(A,:) - coords(C,:), 2 );
S = sign( S_aux(:,3) );

if nnz(S <= 0) > numel(S)/2
    % warning('Switching vertex ordering');
    coords = coords(C,:);

    AB = coords(B,:) - coords(A,:);
    AB_norm = sqrt(sum(AB.^2, 2));
    E = AB ./ AB_norm;
    
    S_aux = cross( coords(B,:) - coords(A,:), coords(A,:) - coords(C,:), 2 );
    S = sign( S_aux(:,3) );
end

LS = inf( size(X) );

for iG = 1:numel(X)
        
    P = [ X(iG), Y(iG), 0 ];
    AP = [ P(1) - coords(A,1), P(2) - coords(A,2), P(3) - coords(A,3) ];
    BP = [ P(1) - coords(B,1), P(2) - coords(B,2), P(3) - coords(B,3) ];
    
    DV = sqrt( diag( AP*AP' ) );
    DE_aux = cross( E, BP, 2 );
    DE_sign = sign( DE_aux(:,3) );
    DE = sqrt( diag( DE_aux*DE_aux' ) );
    PS = diag( E * BP' );
    
    DE( PS>0 | PS./AB_norm < -1 ) = inf;
    
    is_DE_larger = DE > DV;
    minima = min( DE, DV );      
    [ minimum, index ] = min( minima );
    
    if is_DE_larger(index)
        LS(iG) = S(index)*minimum;
    else
        LS(iG) = DE_sign(index)*minimum;
    end;
    
end;




end