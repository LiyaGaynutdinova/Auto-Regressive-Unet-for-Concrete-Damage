function [output, bwImage] = smoothen_particles(inFile, options)

fId = fopen(inFile);
allInput = jsondecode(char(fread(fId)'));
input = allInput.tiles;
fclose(fId);

templateGrid = PointGrid( ...
    input.domain.minBounds(1:2), ...%input.particles(iP).centre(1:2)' - options.increaseRadius * actR, ...
    input.domain.maxBounds(1:2), ...%input.particles(iP).centre(1:2)' + options.increaseRadius * actR, ...
    options.resolution );

allPlot = -templateGrid.distanceField;

output.code = input.codes;
output.domain = input.domain;
output.particles = [];

% Compute maximal circumscribed radius
nP = length(input.particles);
for iP = 1:nP
    
    fprintf('Particle no. %i\n', iP);

    additionalDistance = options.relativeAdditionalDistance * input.particles{iP}.circumscribedRadius;

    p = ParticlePolygon();
    p.coords = [input.particles{iP}.centre(1) + input.particles{iP}.vertices(:,1), ...
        input.particles{iP}.centre(2) + input.particles{iP}.vertices(:,2) ];
    p.centre = input.particles{iP}.centre(1:2)';

    actP = p;
    gridNew = templateGrid.update_with_particle(actP);

    baseVolume = gridNew.volume_fraction(0.00001) * gridNew.volume();
    if baseVolume == 0
        fprintf('\tSkipping because of zero volume')
        continue
    end

    newVolume  = gridNew.volume_fraction(additionalDistance) * gridNew.volume();

    % Compute estimate of what circle fraction is visible
    estBaseVolume = pi * input.particles{iP}.circumscribedRadius^2;
    estNewVolume  = pi * (additionalDistance + input.particles{iP}.circumscribedRadius^2)^2;

    baseRelVolume = baseVolume / estBaseVolume;
    newRelVolume  = newVolume / estNewVolume;

    minVolume = pi() * additionalDistance^2 * (baseRelVolume);
    if minVolume >= baseVolume
        warning('Cannot achieve desired volume (unless only a fraction is shown');
    end

    if options.plotIntermediate
        newFig = figure(1);
        handleL = subplot(1,2,1);
        gridNew.plot_binary(handleL);
    end

    scalings = zeros(options.maxIterations + 1, 1);
    scalings(1) = 1.0;
    volumes = zeros(options.maxIterations + 1, 1);
    volumes(1) = newVolume;
    nEmptyTries = 0.0;


    if options.plotIntermediate
        handleR = subplot(1,2,2);
    end
    iI = 0;
    while abs(baseVolume - newVolume)/baseVolume > options.similarityThreshold ...
       && iI < options.maxIterations

        prevP = actP;

        clear gridNew;
        clear actP

        iI = iI + 1;

        if iI == 1
            scaling = sqrt(baseVolume/newVolume);
        else
            formerCumScalings = scalings(1:iI);
            formerVolumes = volumes(1:iI);

            % Erase multiple zeros
            if nnz(formerVolumes == 0) > 1
                [maxScalingWithZero] = max(formerCumScalings(formerVolumes == 0));
                formerCumScalings = [formerCumScalings(formerVolumes > 0); maxScalingWithZero];
                formerVolumes = [formerVolumes(formerVolumes > 0); 0];
            end

            % Handle multiple entries with the same volume
            [formerUniqueVolumes, uniqueIndx, uniqueBackIndx] = unique(formerVolumes);
            if length(formerUniqueVolumes) ~= length(formerVolumes)
                formerUniqueScaling = zeros(size(formerUniqueVolumes));
                for iV = 1:length(formerUniqueVolumes)
                    altScalings = formerCumScalings(formerVolumes == formerUniqueVolumes(iV));
                    if formerUniqueVolumes(iV) > baseVolume
                        formerUniqueScaling(iV) = min(altScalings);
                    else
                        formerUniqueScaling(iV) = max(altScalings);
                    end 
                end
            else
               formerUniqueScaling = formerCumScalings(uniqueIndx);
            end  

            % Enhance with zero
            if baseVolume < min(formerUniqueVolumes)
                formerUniqueVolumes = [0; formerUniqueVolumes];
                formerUniqueScaling = [0; formerUniqueScaling];
            end
            scaling = interp1(formerUniqueVolumes, formerUniqueScaling, baseVolume, 'makima');
        end
        warningStr = '';
        actP = p.scale( scaling );


        % if newVolume <= 0 && baseVolume > 0
        %     nEmptyTries = nEmptyTries+1;
        %     % Handle the case when scaled down too much (i.e., scale back
        %     % and try to dampen the scaling) 
        %     newScaling = ((2^(nEmptyTries)-1) * 1 + 1 * scalings(iI+1-nEmptyTries)) / 2^(nEmptyTries);
        %     scaling = (1/scalingToRevert) * newScaling;
        %     scalingToRevert = newScaling;
        %     warningStr = 'Zero volume detected, backtracking scaling';
        % else
        %     if nEmptyTries > 0
        %         % Make unique, i.e. choosen the largest scaling with zero volume
        %         formerCumScalings = cumprod(scalings(1:iI));
        %         formerVolumes = volumes(1:iI);
        % 
        %         [maxScalingWithZero] = max(formerCumScalings(formerVolumes == 0));
        %         formerCumScalings = [formerCumScalings(formerVolumes > 0); maxScalingWithZero];
        %         formerVolumes = [formerVolumes(formerVolumes > 0); 0];
        % 
        %         [formerVolumes, uniqueIndx] = unique(formerVolumes);
        %         formerCumScalings = formerCumScalings(uniqueIndx);
        % 
        % 
        %         allTimeScaling = interp1(formerVolumes, formerCumScalings, baseVolume, 'makima');
        %         scaling = 1/formerCumScalings(end) * allTimeScaling;
        %         scalingToRevert = allTimeScaling;
        %     else
        %         scaling = sqrt(baseVolume/newVolume);
        %         scalingToRevert = scaling;
        %     end
        %     nEmptyTries = 0;
        %     warningStr = '';
        % end
        % scalings(iI+1) = scaling;
        % actP = prevP.scale( scaling );

        gridNew = templateGrid.update_with_particle(actP);
        newVolume = gridNew.volume_fraction(additionalDistance) * gridNew.volume();
        
        scalings(iI+1) = scaling;
        volumes(iI+1) = newVolume;

        if options.plotIntermediate
            gridNew.plot_binary(handleR, additionalDistance);
        end

        fprintf('\tiI = %i, scaling = %f (Vact = %f vs Vtarg = %f) %s\n', iI, scaling, newVolume, baseVolume, warningStr);

        if (iI == options.maxIterations) && (abs(baseVolume - newVolume)/baseVolume > options.similarityThreshold)
            fprintf('\t\tReached iteration limit, choosing the closest option\n')
            allScalings = scalings;
            [~,minInd] = min(abs(volumes - baseVolume));
            checkVolume = volumes(minInd);
            actP = p.scale( allScalings(minInd) );

            gridNew = templateGrid.update_with_particle(actP);
            newVolume = gridNew.volume_fraction(additionalDistance) * gridNew.volume();
    
            if options.plotIntermediate
                gridNew.plot_binary(handleR, additionalDistance);
            end
            assert( checkVolume == newVolume, 'Volumes are distinct');

        end

    end

    if isempty(output.particles)
        output.particles = [actP];
    else
        output.particles(end+1) = actP;
    end

    if options.plotIntermediate
        gridNew.plot_binary(handleR, additionalDistance);
    end

    allPlot = max(allPlot, gridNew.distanceField + additionalDistance);

end

bwImage = rot90(allPlot>0);

end