classdef ParticlePolygon
   
    properties
        centre;
        coords;        
    end
    
    methods
       
        function A = area(obj)
            
        end
        
        function [minmaxSpacing] = min_square_sieve_spacing(obj, n)
            
            % Only quarter rotation is OK since we are looking for min-max
            if nargin == 1
                n = 10;
            end
            
            minmaxSpacing = Inf;
            angles = (0:1:n)/n * pi/2;
            for iA = 1:length(angles)
                sA = sin(angles(iA));
                cA = cos(angles(iA));
                
                rotCoords = [cA, -sA; sA, cA] * obj.coords';
                maxSpacing = max(max(rotCoords, [], 2) - min(rotCoords, [], 2));
                
                minmaxSpacing = min(minmaxSpacing, maxSpacing);
            end
            
        end
        
        function new = scale(obj, scaleFactor)
            
            new = ParticlePolygon();
            new.centre = obj.centre;
            
            new.coords = zeros(size(obj.coords));
            for iV = 1:size(obj.coords,1)
                C = obj.centre;
                CV = obj.coords(iV,:) - C;
                new.coords(iV,:) = C + scaleFactor * CV;
            end
            
        end
        
        function new = shift(obj, shift)
            
            new = ParticlePolygon();
            new.centre = obj.centre + shift;
            new.coords = obj.coords + repmat(shift, [size(obj.coords,1), 1]);
            
        end
        
        function LS = distance_field(obj, grid)
            
            LS = compute_LS_polygon_v2(...
                obj.coords, ...
                grid.X, grid.Y );
            
        end
        
    end   
    
end