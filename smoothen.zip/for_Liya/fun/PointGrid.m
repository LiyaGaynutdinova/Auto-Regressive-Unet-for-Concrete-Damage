classdef PointGrid
    
    properties (SetAccess = private)
       minBounds;
       maxBounds;
       resolution;
       
       X;
       Y;    
       
       periodicX = false;
       periodicY = false;
       
       distanceField;
    end
    
    methods
        
        function obj = PointGrid(minBounds, maxBounds, resolution)
            
            obj.minBounds = minBounds;
            obj.maxBounds = maxBounds;
            obj.resolution = resolution;
            
            [ obj.Y, obj.X ] = ...
                meshgrid( minBounds(2):(maxBounds(2)-minBounds(2))/(resolution(2)-1):maxBounds(2),...
                          minBounds(1):(maxBounds(1)-minBounds(1))/(resolution(1)-1):maxBounds(1) );
                      
            obj.distanceField = norm(maxBounds - minBounds) * ones(size(obj.X)); 
            
        end     
        
        function obj = set_periodicity(obj, periodicityMask)
           obj.periodicX = periodicityMask(1);
           obj.periodicY = periodicityMask(2);
        end
        
        function [indices, coords, validityMap] = candidate_point(obj, minDistance, maxDistance)
           
            if nargin <= 2
                maxDistance = inf;
            end
            
            validityMap = obj.distanceField(:) >= minDistance & obj.distanceField(:) <= maxDistance;
            
            nCandidatePoints = nnz(validityMap);
            if nCandidatePoints == 0
                indices = [];
                coords = [];
                return
            end
            
            chosenPoint = randi(nCandidatePoints);
            chosenIndex = find(cumsum(validityMap) == chosenPoint, 1);
            
            [indices.r, indices.c] = ind2sub(obj.resolution, chosenIndex);            
            coords.x = obj.X(indices.r, indices.c);
            coords.y = obj.Y(indices.r, indices.c);           
            
        end
        
        function iFig = plot(obj)
            iFig = figure();
            surf(obj.X, obj.Y, obj.distanceField, 'EdgeColor', 'none'); 
            view(2);
            axis equal;
        end
        
        function iFig = plot_binary(obj, handle, threshold)
            if nargin >= 2 
                if ishandle(handle) && strcmp(get(handle, 'Type'), 'figure')
                    iFig = figure(handle);
                elseif ishandle(handle) && strcmp(get(handle, 'Type'), 'axes')
                    axes(handle);
                else
                    error('Unsupported parameter passed (must be a handle to either a figure or axes')
                end
            else
                iFig = figure();
            end
            if nargin < 3
                threshold = 0.0;
            end
            imshow(rot90(-obj.distanceField <= threshold), 'Parent', gca());
        end
        
        function obj = prevent_corner_overlaps(obj)
            obj.distanceField(:) = min( ...
                obj.distanceField(:), ...
                ((obj.X(:) - obj.minBounds(1)).^2 + (obj.Y(:) - obj.minBounds(2)).^2).^(1/2) );
            obj.distanceField(:) = min( ...
                obj.distanceField(:), ...
                ((obj.X(:) - obj.maxBounds(1)).^2 + (obj.Y(:) - obj.minBounds(2)).^2).^(1/2) );
            obj.distanceField(:) = min( ...
                obj.distanceField(:), ...
                ((obj.X(:) - obj.minBounds(1)).^2 + (obj.Y(:) - obj.maxBounds(2)).^2).^(1/2) );
            obj.distanceField(:) = min( ...
                obj.distanceField(:), ...
                ((obj.X(:) - obj.maxBounds(1)).^2 + (obj.Y(:) - obj.maxBounds(2)).^2).^(1/2) );
        end
        
        function obj = prevent_edge_overlaps(obj, mask)
            if nargin < 1
                mask = [true, true, true, true];
            end
            
            if mask(1)
            obj.distanceField(:) = min( ...
                obj.distanceField(:), ...
                abs(obj.X(:) - obj.minBounds(1)) );
            end
            if mask(2)
            obj.distanceField(:) = min( ...
                obj.distanceField(:), ...
                abs(obj.X(:) - obj.maxBounds(1)) );
            end
            if mask(3)
            obj.distanceField(:) = min( ...
                obj.distanceField(:), ...
                abs(obj.Y(:) - obj.minBounds(2)) );
            end
            if mask(4)
            obj.distanceField(:) = min( ...
                obj.distanceField(:), ...
                abs(obj.Y(:) - obj.maxBounds(2)) );
            end
        end
        
        function obj = update_with_particle(obj, particle)
            
            LS = particle.distance_field(obj);
            obj.distanceField = min(obj.distanceField, LS);
            
            shift = obj.maxBounds - obj.minBounds;
            if obj.periodicX
                tempParticle = particle;
                tempParticle.coords(:,1) = particle.coords(:,1) - shift(1);
                tempParticle.centre(1) = particle.centre(1) - shift(1);
                
                LSminus = tempParticle.distance_field(obj);
                obj.distanceField = min(obj.distanceField, LSminus);
                
                tempParticle.coords(:,1) = particle.coords(:,1) + shift(1);
                tempParticle.centre(1) = particle.centre(1) + shift(1);
                
                LSplus = tempParticle.distance_field(obj);
                obj.distanceField = min(obj.distanceField, LSplus);
            end
            if obj.periodicY
                tempParticle = particle;
                tempParticle.coords(:,2) = particle.coords(:,2) - shift(2);
                tempParticle.centre(2) = particle.centre(2) - shift(2);
                
                LSminus = tempParticle.distance_field(obj);
                obj.distanceField = min(obj.distanceField, LSminus);
                
                tempParticle.coords(:,2) = particle.coords(:,2) + shift(2);
                tempParticle.centre(2) = particle.centre(2) + shift(2);
                
                LSplus = tempParticle.distance_field(obj);
                obj.distanceField = min(obj.distanceField, LSplus);
            end
            if obj.periodicX && obj.periodicY
                tempParticle = particle;
                tempParticle.coords(:,1) = particle.coords(:,1) - shift(1);
                tempParticle.coords(:,2) = particle.coords(:,2) - shift(2);
                tempParticle.centre(1) = particle.centre(1) - shift(1);
                tempParticle.centre(2) = particle.centre(2) - shift(2);
                
                LS = tempParticle.distance_field(obj);
                obj.distanceField = min(obj.distanceField, LS);
                
                tempParticle.coords(:,1) = particle.coords(:,1) + shift(1);
                tempParticle.coords(:,2) = particle.coords(:,2) - shift(2);
                tempParticle.centre(1) = particle.centre(1) + shift(1);
                tempParticle.centre(2) = particle.centre(2) - shift(2);
                
                LS = tempParticle.distance_field(obj);
                obj.distanceField = min(obj.distanceField, LS);
                
                tempParticle.coords(:,1) = particle.coords(:,1) - shift(1);
                tempParticle.coords(:,2) = particle.coords(:,2) + shift(2);
                tempParticle.centre(1) = particle.centre(1) - shift(1);
                tempParticle.centre(2) = particle.centre(2) + shift(2);
                
                LS = tempParticle.distance_field(obj);
                obj.distanceField = min(obj.distanceField, LS);
                
                tempParticle.coords(:,1) = particle.coords(:,1) + shift(1);
                tempParticle.coords(:,2) = particle.coords(:,2) + shift(2);
                tempParticle.centre(1) = particle.centre(1) + shift(1);
                tempParticle.centre(2) = particle.centre(2) + shift(2);
                
                LS = tempParticle.distance_field(obj);
                obj.distanceField = min(obj.distanceField, LS);
            end
            
            
        end
        
        function vol = volume(obj)
           nonzeroMask = (obj.maxBounds ~= obj.minBounds);
           vol = prod(obj.maxBounds(nonzeroMask) - obj.minBounds(nonzeroMask));
        end
        
        function volFrac = volume_fraction(obj, threshold)
            if nargin == 1
                threshold = 0;
            end
           volFrac = nnz(-obj.distanceField < threshold) / numel(obj.distanceField); 
        end
        
    end

end